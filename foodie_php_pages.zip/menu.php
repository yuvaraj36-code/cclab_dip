<?php
// menu.php — Browse available food items and send a selection to the order form.
$foods = [
 ['id'=>'burger','name'=>'Classic Burger','category'=>'Burgers','description'=>'Grilled patty, crisp lettuce, tomato and house sauce.','price'=>199,'image'=>'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=85','tag'=>'Bestseller'],
 ['id'=>'pizza','name'=>'Margherita Pizza','category'=>'Pizza','description'=>'Mozzarella, fresh basil and rich tomato sauce.','price'=>349,'image'=>'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=900&q=85','tag'=>'Popular'],
 ['id'=>'pasta','name'=>'Creamy Pasta','category'=>'Pasta','description'=>'Silky white sauce, herbs and parmesan.','price'=>279,'image'=>'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=900&q=85','tag'=>'Chef pick'],
 ['id'=>'fries','name'=>'Crispy French Fries','category'=>'Sides','description'=>'Golden, crunchy fries with a pinch of seasoning.','price'=>99,'image'=>'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=900&q=85','tag'=>'Snack'],
 ['id'=>'salad','name'=>'Garden Fresh Salad','category'=>'Healthy','description'=>'Seasonal greens, cucumber, tomato and zesty dressing.','price'=>179,'image'=>'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=900&q=85','tag'=>'Fresh'],
 ['id'=>'sandwich','name'=>'Grilled Sandwich','category'=>'Snacks','description'=>'Toasted bread, melted cheese and fresh vegetables.','price'=>149,'image'=>'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=900&q=85','tag'=>'Comfort food'],
 ['id'=>'taco','name'=>'Loaded Tacos','category'=>'Mexican','description'=>'Crunchy shells filled with spiced vegetables and salsa.','price'=>229,'image'=>'https://images.unsplash.com/photo-1551502179-5a6b7e3c7f6b?auto=format&fit=crop&w=900&q=85','tag'=>'Flavourful'],
 ['id'=>'brownie','name'=>'Chocolate Brownie','category'=>'Desserts','description'=>'Rich chocolate brownie, baked until fudgy.','price'=>129,'image'=>'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=900&q=85','tag'=>'Sweet treat'],
 ['id'=>'lemonade','name'=>'Fresh Lemonade','category'=>'Drinks','description'=>'Fresh lemon, a little sweetness and lots of refreshment.','price'=>79,'image'=>'https://images.unsplash.com/photo-1513558161293-cdaf765edfd7?auto=format&fit=crop&w=900&q=85','tag'=>'Cool down'],
];
function e($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Menu — Foodie</title>
<style>
:root{--ink:#17211b;--muted:#68736b;--green:#1d6b45;--lime:#d9f36a;--cream:#f7f8f2;--white:#fff;--line:#e6e9e0}*{box-sizing:border-box}body{margin:0;font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;background:var(--cream);color:var(--ink)}a{text-decoration:none;color:inherit}.wrap{width:min(1160px,92%);margin:auto}.nav{height:82px;display:flex;align-items:center;justify-content:space-between;gap:20px}.brand{font-weight:900;font-size:1.55rem;letter-spacing:-1px}.brand span{color:var(--green)}.links{display:flex;gap:28px;color:#526057;font-size:.95rem}.links a.active,.links a:hover{color:var(--green)}.nav-cta,.btn{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:999px;background:var(--green);color:white;padding:13px 20px;font-weight:750;cursor:pointer}.page-head{padding:44px 0 26px}.eyebrow{display:inline-block;background:#e8f1d9;color:var(--green);border-radius:999px;padding:8px 13px;font-size:.82rem;font-weight:800}.page-head h1{font-size:clamp(2.5rem,6vw,4.4rem);letter-spacing:-.06em;line-height:1;margin:18px 0 12px}.page-head p{color:var(--muted);font-size:1.05rem;line-height:1.7;margin:0;max-width:650px}.filters{display:flex;gap:10px;flex-wrap:wrap;margin:22px 0 28px}.filter{border:1px solid var(--line);background:white;padding:10px 16px;border-radius:999px;font-weight:700;cursor:pointer;color:var(--ink)}.filter.active,.filter:hover{background:var(--ink);color:white;border-color:var(--ink)}.foods{display:grid;grid-template-columns:repeat(3,1fr);gap:22px;padding-bottom:75px}.food-card{background:white;border:1px solid var(--line);border-radius:24px;overflow:hidden}.food-card img{width:100%;height:210px;object-fit:cover;display:block}.food-content{padding:18px}.tag{font-size:.72rem;font-weight:800;background:#f0f5e8;color:var(--green);padding:6px 9px;border-radius:999px}.food-title{display:flex;justify-content:space-between;align-items:center;gap:10px;margin:13px 0 8px}.food-title h2{font-size:1.12rem;margin:0}.price{font-weight:900;white-space:nowrap}.food-content p{color:var(--muted);font-size:.9rem;line-height:1.6;min-height:43px}.food-bottom{display:flex;justify-content:space-between;align-items:center;margin-top:16px}.category{font-size:.8rem;color:var(--muted)}.add{background:var(--lime);color:var(--ink);padding:10px 15px;border-radius:999px;font-weight:850}footer{border-top:1px solid var(--line);padding:25px 0;color:var(--muted);font-size:.9rem}.footer-inner{display:flex;justify-content:space-between;gap:18px;flex-wrap:wrap}.empty{display:none;padding:25px;text-align:center;color:var(--muted)}@media(max-width:760px){.links{gap:13px;font-size:.86rem}.nav-cta{display:none}.foods{grid-template-columns:repeat(2,1fr)}}@media(max-width:520px){.foods{grid-template-columns:1fr}.food-card img{height:235px}.nav{height:70px}.brand{font-size:1.25rem}.links{gap:10px}}
</style>
</head>
<body>
<header class="wrap nav"><a class="brand" href="home.php">foodie<span>.</span></a><nav class="links"><a href="home.php">Home</a><a class="active" href="menu.php">Menu</a><a href="order.php">Order</a></nav><a class="nav-cta" href="order.php">Order now ↗</a></header>
<main class="wrap">
  <section class="page-head"><span class="eyebrow">✦ Made fresh for you</span><h1>Find your flavour.</h1><p>From comfort-food classics to fresh favourites, there is something delicious waiting for you.</p></section>
  <div class="filters" role="group" aria-label="Filter menu by category">
    <button class="filter active" data-category="all">All items</button>
    <?php foreach (array_unique(array_column($foods, 'category')) as $category): ?><button class="filter" data-category="<?= e($category) ?>"><?= e($category) ?></button><?php endforeach; ?>
  </div>
  <div class="foods" id="food-grid">
  <?php foreach ($foods as $food): ?>
    <article class="food-card" data-food-category="<?= e($food['category']) ?>">
      <img src="<?= e($food['image']) ?>" alt="<?= e($food['name']) ?>" loading="lazy">
      <div class="food-content"><span class="tag"><?= e($food['tag']) ?></span><div class="food-title"><h2><?= e($food['name']) ?></h2><span class="price">₹<?= number_format($food['price']) ?></span></div>
      <p><?= e($food['description']) ?></p><div class="food-bottom"><span class="category"><?= e($food['category']) ?></span><a class="add" href="order.php?item=<?= urlencode($food['name']) ?>">Order +</a></div></div>
    </article>
  <?php endforeach; ?>
  </div><p class="empty" id="empty-state">No items in this category yet.</p>
</main>
<footer><div class="wrap footer-inner"><a class="brand" href="home.php">foodie<span>.</span></a><span>Made with love for hungry people.</span><span>© <?= date('Y') ?> Foodie</span></div></footer>
<script>
const filters = document.querySelectorAll('.filter');
const cards = document.querySelectorAll('.food-card');
const empty = document.getElementById('empty-state');
filters.forEach(button => button.addEventListener('click', () => {
  filters.forEach(item => item.classList.remove('active'));
  button.classList.add('active');
  const category = button.dataset.category;
  let visible = 0;
  cards.forEach(card => {
    const show = category === 'all' || card.dataset.foodCategory === category;
    card.style.display = show ? '' : 'none';
    if (show) visible++;
  });
  empty.style.display = visible ? 'none' : 'block';
}));
</script>
</body></html>
