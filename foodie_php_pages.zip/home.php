<?php
// home.php — Foodie online food ordering home page
$featuredFoods = [
    ['name' => 'Classic Burger', 'description' => 'Juicy grilled patty, fresh lettuce and house sauce.', 'price' => 199, 'image' => 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=85', 'tag' => 'Bestseller'],
    ['name' => 'Margherita Pizza', 'description' => 'Mozzarella, basil and rich tomato sauce.', 'price' => 349, 'image' => 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=900&q=85', 'tag' => 'Popular'],
    ['name' => 'Creamy Pasta', 'description' => 'Creamy white sauce with herbs and parmesan.', 'price' => 279, 'image' => 'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=900&q=85', 'tag' => 'Chef pick'],
];
function e($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Foodie — Good food, good mood</title>
<style>
:root{--ink:#17211b;--muted:#68736b;--green:#1d6b45;--lime:#d9f36a;--cream:#f7f8f2;--white:#fff;--line:#e6e9e0}
*{box-sizing:border-box}body{margin:0;font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;background:var(--cream);color:var(--ink)}a{text-decoration:none;color:inherit}.wrap{width:min(1160px,92%);margin:auto}.nav{height:82px;display:flex;align-items:center;justify-content:space-between;gap:20px}.brand{font-weight:900;font-size:1.55rem;letter-spacing:-1px}.brand span{color:var(--green)}.links{display:flex;align-items:center;gap:28px;color:#526057;font-size:.95rem}.links a.active,.links a:hover{color:var(--green)}.nav-cta,.btn{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:999px;background:var(--green);color:white;padding:13px 20px;font-weight:750;cursor:pointer}.hero{display:grid;grid-template-columns:1.05fr .95fr;align-items:center;gap:42px;padding:48px 0 62px}.eyebrow{display:inline-block;background:#e8f1d9;color:var(--green);border-radius:999px;padding:8px 13px;font-size:.82rem;font-weight:800}.hero h1{font-size:clamp(2.8rem,6vw,5.3rem);line-height:.98;letter-spacing:-.065em;margin:20px 0}.hero h1 em{font-style:normal;color:var(--green)}.hero p{font-size:1.08rem;line-height:1.8;color:var(--muted);max-width:490px}.hero-actions{display:flex;gap:13px;align-items:center;margin-top:26px;flex-wrap:wrap}.btn.secondary{background:white;color:var(--ink);border:1px solid var(--line)}.hero-image{position:relative}.hero-image img{width:100%;height:490px;object-fit:cover;border-radius:34px;display:block}.floating{position:absolute;left:-20px;bottom:25px;background:white;padding:15px 19px;border-radius:18px;box-shadow:0 12px 35px #18281b18}.floating strong{display:block}.floating small{color:var(--muted)}.section-head{display:flex;align-items:end;justify-content:space-between;gap:20px;margin:18px 0 24px}.section-head h2{font-size:clamp(1.8rem,4vw,2.6rem);letter-spacing:-.045em;margin:0}.section-head p{color:var(--muted);margin:8px 0 0}.text-link{font-weight:800;color:var(--green)}.foods{display:grid;grid-template-columns:repeat(3,1fr);gap:22px;padding-bottom:76px}.food-card{background:white;border:1px solid var(--line);border-radius:24px;overflow:hidden}.food-card img{width:100%;height:220px;object-fit:cover;display:block}.food-content{padding:19px}.tag{font-size:.72rem;font-weight:800;background:#f0f5e8;color:var(--green);padding:6px 9px;border-radius:999px}.food-title{display:flex;justify-content:space-between;align-items:center;gap:10px;margin:13px 0 8px}.food-title h3{margin:0;font-size:1.16rem}.price{font-weight:900;white-space:nowrap}.food-content p{color:var(--muted);font-size:.92rem;line-height:1.6;min-height:44px}.food-bottom{display:flex;justify-content:space-between;align-items:center;margin-top:16px}.add{background:var(--lime);color:var(--ink);padding:10px 15px;border-radius:999px;font-weight:850}.promo{margin:0 0 70px;background:var(--ink);color:white;padding:34px 38px;border-radius:28px;display:flex;align-items:center;justify-content:space-between;gap:24px}.promo h2{font-size:clamp(1.5rem,3vw,2.2rem);margin:0 0 8px}.promo p{color:#bdc8bf;margin:0}.promo .btn{background:var(--lime);color:var(--ink);white-space:nowrap}footer{border-top:1px solid var(--line);padding:25px 0;color:var(--muted);font-size:.9rem}.footer-inner{display:flex;justify-content:space-between;gap:18px;flex-wrap:wrap}
@media(max-width:760px){.links{gap:13px;font-size:.86rem}.nav-cta{display:none}.hero{grid-template-columns:1fr;padding-top:25px}.hero-image img{height:340px}.floating{left:10px}.foods{grid-template-columns:1fr}.food-card img{height:240px}.promo{align-items:flex-start;flex-direction:column;padding:28px}.section-head{align-items:flex-start;flex-direction:column}}@media(max-width:420px){.links{gap:9px}.brand{font-size:1.25rem}.nav{height:70px}.hero h1{font-size:2.7rem}}
</style>
</head>
<body>
<header class="wrap nav">
  <a class="brand" href="home.php">foodie<span>.</span></a>
  <nav class="links" aria-label="Main navigation">
    <a class="active" href="home.php">Home</a><a href="menu.php">Menu</a><a href="order.php">Order</a>
  </nav>
  <a class="nav-cta" href="order.php">Order now ↗</a>
</header>
<main>
<section class="wrap hero">
  <div>
    <span class="eyebrow">✦ Freshly made, happily delivered</span>
    <h1>Good food.<br><em>Good mood.</em></h1>
    <p>Your cravings called. Discover delicious favourites made fresh and delivered straight to your door.</p>
    <div class="hero-actions"><a class="btn" href="menu.php">Explore menu&nbsp; →</a><a class="btn secondary" href="order.php">Place an order</a></div>
  </div>
  <div class="hero-image">
    <img src="https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=1200&q=90" alt="Freshly prepared meal on a table">
    <div class="floating"><strong>★ 4.9 / 5</strong><small>Loved by food lovers</small></div>
  </div>
</section>
<section class="wrap">
  <div class="section-head"><div><h2>Fan favourites</h2><p>The dishes everyone keeps coming back for.</p></div><a class="text-link" href="menu.php">View full menu →</a></div>
  <div class="foods">
  <?php foreach ($featuredFoods as $food): ?>
    <article class="food-card">
      <img src="<?= e($food['image']) ?>" alt="<?= e($food['name']) ?>" loading="lazy">
      <div class="food-content"><span class="tag"><?= e($food['tag']) ?></span>
        <div class="food-title"><h3><?= e($food['name']) ?></h3><span class="price">₹<?= number_format($food['price']) ?></span></div>
        <p><?= e($food['description']) ?></p>
        <div class="food-bottom"><span>Freshly prepared</span><a class="add" href="order.php?item=<?= urlencode($food['name']) ?>">Order +</a></div>
      </div>
    </article>
  <?php endforeach; ?>
  </div>
  <section class="promo"><div><h2>Your next favourite meal is one click away.</h2><p>Fresh ingredients. Big flavours. No fuss.</p></div><a class="btn" href="menu.php">Find your food →</a></section>
</section>
</main>
<footer><div class="wrap footer-inner"><a class="brand" href="home.php">foodie<span>.</span></a><span>Made with love for hungry people.</span><span>© <?= date('Y') ?> Foodie</span></div></footer>
</body>
</html>
