<?php
// order.php — Validates and displays an order confirmation (no database required).
session_start();
$foods = [
 'Classic Burger'=>199, 'Margherita Pizza'=>349, 'Creamy Pasta'=>279,
 'Crispy French Fries'=>99, 'Garden Fresh Salad'=>179, 'Grilled Sandwich'=>149,
 'Loaded Tacos'=>229, 'Chocolate Brownie'=>129, 'Fresh Lemonade'=>79
];
function e($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
$selected = isset($_GET['item']) ? (string)$_GET['item'] : '';
if (!isset($foods[$selected])) $selected = 'Classic Burger';
$errors = [];
$success = false;
$orderSummary = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim((string)($_POST['customer_name'] ?? ''));
    $phone = trim((string)($_POST['phone'] ?? ''));
    $address = trim((string)($_POST['address'] ?? ''));
    $item = (string)($_POST['item'] ?? '');
    $quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);
    $notes = trim((string)($_POST['notes'] ?? ''));
    if ($name === '' || strlen($name) < 2) $errors[] = 'Please enter your name (at least 2 characters).';
    if (!preg_match('/^[0-9+\-\s()]{7,20}$/', $phone)) $errors[] = 'Please enter a valid phone number.';
    if ($address === '' || strlen($address) < 8) $errors[] = 'Please enter a complete delivery address.';
    if (!isset($foods[$item])) $errors[] = 'Please choose a valid food item.';
    if ($quantity === false || $quantity < 1 || $quantity > 20) $errors[] = 'Quantity must be between 1 and 20.';
    if (!$errors) {
        $success = true;
        $orderSummary = ['name'=>$name,'phone'=>$phone,'address'=>$address,'item'=>$item,'quantity'=>$quantity,'notes'=>$notes,'total'=>$foods[$item]*$quantity,'order_id'=>'FD'.date('ymd').strtoupper(bin2hex(random_bytes(2))),'time'=>date('d M Y, h:i A')];
        $_SESSION['last_order'] = $orderSummary;
    }
}
?>
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Place an order — Foodie</title>
<style>
:root{--ink:#17211b;--muted:#68736b;--green:#1d6b45;--lime:#d9f36a;--cream:#f7f8f2;--white:#fff;--line:#e6e9e0;--red:#9e2c26}*{box-sizing:border-box}body{margin:0;font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;background:var(--cream);color:var(--ink)}a{text-decoration:none;color:inherit}.wrap{width:min(1160px,92%);margin:auto}.nav{height:82px;display:flex;align-items:center;justify-content:space-between;gap:20px}.brand{font-weight:900;font-size:1.55rem;letter-spacing:-1px}.brand span{color:var(--green)}.links{display:flex;gap:28px;color:#526057;font-size:.95rem}.links a.active,.links a:hover{color:var(--green)}.nav-cta,.btn{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:999px;background:var(--green);color:white;padding:13px 20px;font-weight:750;cursor:pointer}.page-head{padding:38px 0 26px}.eyebrow{display:inline-block;background:#e8f1d9;color:var(--green);border-radius:999px;padding:8px 13px;font-size:.82rem;font-weight:800}.page-head h1{font-size:clamp(2.5rem,6vw,4.1rem);letter-spacing:-.06em;line-height:1;margin:18px 0 12px}.page-head p{color:var(--muted);line-height:1.7;margin:0}.layout{display:grid;grid-template-columns:1.2fr .8fr;gap:24px;align-items:start;padding-bottom:76px}.panel{background:white;border:1px solid var(--line);border-radius:25px;padding:27px}.panel h2{margin:0 0 7px;font-size:1.45rem;letter-spacing:-.03em}.sub{color:var(--muted);font-size:.92rem;line-height:1.6;margin:0 0 23px}.field{margin-bottom:17px}.field label{display:block;font-weight:750;font-size:.9rem;margin-bottom:8px}.field input,.field textarea,.field select{width:100%;padding:13px 14px;border:1px solid #dfe4da;border-radius:12px;background:#fff;font:inherit;color:var(--ink);outline:none}.field input:focus,.field textarea:focus,.field select:focus{border-color:var(--green);box-shadow:0 0 0 3px #1d6b4518}.field textarea{min-height:95px;resize:vertical}.two{display:grid;grid-template-columns:1fr 1fr;gap:14px}.btn{width:100%;font:inherit;font-weight:800;font-size:1rem;padding:15px}.summary{background:var(--ink);color:white;border-radius:25px;padding:25px;position:sticky;top:20px}.summary h2{margin:0 0 7px;font-size:1.4rem}.summary>p{color:#bdc8bf;line-height:1.6;font-size:.9rem;margin:0 0 20px}.summary-row{display:flex;justify-content:space-between;gap:12px;padding:13px 0;border-bottom:1px solid #ffffff20}.summary-row span:first-child{color:#c7d0c9}.summary-total{display:flex;justify-content:space-between;font-size:1.2rem;font-weight:900;padding:20px 0}.note{font-size:.82rem;color:#bdc8bf;line-height:1.6}.alert{padding:15px 17px;border-radius:14px;margin-bottom:20px}.error{background:#fff0ee;border:1px solid #f3c4bf;color:var(--red)}.success{background:#e9f7e9;border:1px solid #b9dfb8;color:#185c2b}.success h2{margin:0 0 8px}.success p{margin:6px 0;line-height:1.55}.receipt{margin-bottom:22px}.receipt strong{color:var(--ink)}.footer{border-top:1px solid var(--line);padding:25px 0;color:var(--muted);font-size:.9rem}.footer-inner{display:flex;justify-content:space-between;gap:18px;flex-wrap:wrap}@media(max-width:760px){.links{gap:13px;font-size:.86rem}.nav-cta{display:none}.layout{grid-template-columns:1fr}.summary{position:static}.two{grid-template-columns:1fr}.nav{height:70px}.brand{font-size:1.25rem}.links{gap:10px}.panel{padding:21px}}
</style></head><body>
<header class="wrap nav"><a class="brand" href="home.php">foodie<span>.</span></a><nav class="links"><a href="home.php">Home</a><a href="menu.php">Menu</a><a class="active" href="order.php">Order</a></nav><a class="nav-cta" href="menu.php">Browse menu ↗</a></header>
<main class="wrap">
<section class="page-head"><span class="eyebrow">✦ Almost time to eat</span><h1>Make it yours.</h1><p>Tell us where to deliver your favourites. We’ll take care of the delicious part.</p></section>
<?php if ($success): ?>
  <section class="alert success receipt" role="status">
    <h2>✓ Thanks, <?= e($orderSummary['name']) ?>! Your order is ready.</h2>
    <p><strong>Order reference:</strong> <?= e($orderSummary['order_id']) ?></p>
    <p><?= e($orderSummary['quantity']) ?> × <?= e($orderSummary['item']) ?> · Total: <strong>₹<?= number_format($orderSummary['total']) ?></strong></p>
    <p><strong>Delivery address:</strong> <?= e($orderSummary['address']) ?></p>
    <p><em>Demo notice: this sample page displays an order confirmation but does not send the order to a restaurant or save it to a database.</em></p>
  </section>
<?php endif; ?>
<div class="layout">
<section class="panel">
  <h2>Delivery details</h2><p class="sub">Enter your details below to place a demo order.</p>
  <?php if ($errors): ?><div class="alert error" role="alert"><?php foreach ($errors as $error): ?><div>• <?= e($error) ?></div><?php endforeach; ?></div><?php endif; ?>
  <form method="post" action="order.php" novalidate>
    <div class="field"><label for="customer_name">Full name *</label><input id="customer_name" name="customer_name" required minlength="2" autocomplete="name" value="<?= e($_POST['customer_name'] ?? '') ?>" placeholder="Your name"></div>
    <div class="two">
      <div class="field"><label for="phone">Phone number *</label><input id="phone" name="phone" required autocomplete="tel" value="<?= e($_POST['phone'] ?? '') ?>" placeholder="+91 98765 43210"></div>
      <div class="field"><label for="quantity">Quantity *</label><select id="quantity" name="quantity" required><?php for ($q=1;$q<=10;$q++): ?><option value="<?= $q ?>" <?= (string)($_POST['quantity'] ?? '1') === (string)$q ? 'selected' : '' ?>><?= $q ?></option><?php endfor; ?></select></div>
    </div>
    <div class="field"><label for="address">Delivery address *</label><textarea id="address" name="address" required minlength="8" autocomplete="street-address" placeholder="House number, street, area, city, PIN code"><?= e($_POST['address'] ?? '') ?></textarea></div>
    <div class="field"><label for="item">Choose your food *</label><select id="item" name="item" required><?php foreach ($foods as $foodName=>$price): ?><option value="<?= e($foodName) ?>" data-price="<?= $price ?>" <?= (($_POST['item'] ?? $selected) === $foodName) ? 'selected' : '' ?>><?= e($foodName) ?> — ₹<?= number_format($price) ?></option><?php endforeach; ?></select></div>
    <div class="field"><label for="notes">Special instructions (optional)</label><textarea id="notes" name="notes" placeholder="Any allergies or delivery notes?"><?= e($_POST['notes'] ?? '') ?></textarea></div>
    <button class="btn" type="submit">Place demo order&nbsp; →</button>
  </form>
</section>
<aside class="summary">
  <h2>Your order</h2><p>A little something delicious, coming right up.</p>
  <div class="summary-row"><span>Selected item</span><strong id="summary-item"><?= e($_POST['item'] ?? $selected) ?></strong></div>
  <div class="summary-row"><span>Price</span><strong id="summary-price">₹<?= number_format($foods[$_POST['item'] ?? $selected] ?? $foods[$selected]) ?></strong></div>
  <div class="summary-row"><span>Quantity</span><strong id="summary-quantity"><?= e($_POST['quantity'] ?? '1') ?></strong></div>
  <div class="summary-total"><span>Total</span><span id="summary-total">₹<?= number_format(($foods[$_POST['item'] ?? $selected] ?? $foods[$selected]) * max(1,(int)($_POST['quantity'] ?? 1))) ?></span></div>
  <p class="note">Prices are in Indian rupees (INR). This starter project does not include payment processing, live delivery tracking or database storage.</p>
</aside>
</div>
</main>
<footer class="footer"><div class="wrap footer-inner"><a class="brand" href="home.php">foodie<span>.</span></a><span>Made with love for hungry people.</span><span>© <?= date('Y') ?> Foodie</span></div></footer>
<script>
const itemSelect = document.getElementById('item');
const quantitySelect = document.getElementById('quantity');
const summaryItem = document.getElementById('summary-item');
const summaryPrice = document.getElementById('summary-price');
const summaryQuantity = document.getElementById('summary-quantity');
const summaryTotal = document.getElementById('summary-total');
function updateSummary(){
 const option = itemSelect.options[itemSelect.selectedIndex];
 const price = Number(option.dataset.price || 0);
 const quantity = Number(quantitySelect.value || 1);
 const format = n => '₹' + n.toLocaleString('en-IN');
 summaryItem.textContent = option.value;
 summaryPrice.textContent = format(price);
 summaryQuantity.textContent = quantity;
 summaryTotal.textContent = format(price * quantity);
}
itemSelect.addEventListener('change', updateSummary);
quantitySelect.addEventListener('change', updateSummary);
updateSummary();
</script></body></html>
