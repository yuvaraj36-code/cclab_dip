package com.example.kotlinloginregister

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    LoginRegisterScreen()
                }
            }
        }
    }
}

@Composable
private fun LoginRegisterScreen() {
    val context = LocalContext.current
    var isRegister by remember { mutableStateOf(false) }
    var loggedIn by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    // Demo-only account data, kept in memory while the app process runs.
    var savedName by remember { mutableStateOf("") }
    var savedEmail by remember { mutableStateOf("") }
    var savedPassword by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (loggedIn) {
            Text("Welcome, $savedName!", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text("Login Successful")
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = {
                    loggedIn = false
                    email = ""
                    password = ""
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("LOGOUT") }
        } else {
            Text(
                if (isRegister) "Create Account" else "Welcome Back!",
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(Modifier.height(8.dp))
            Text(if (isRegister) "Register your account" else "Login to continue")
            Spacer(Modifier.height(24.dp))

            if (isRegister) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
            }

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password (minimum 6 characters)") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(20.dp))

            Button(
                onClick = {
                    when {
                        email.isBlank() || password.isBlank() ->
                            Toast.makeText(context, "Fill in email and password", Toast.LENGTH_SHORT).show()
                        isRegister && name.isBlank() ->
                            Toast.makeText(context, "Enter your name", Toast.LENGTH_SHORT).show()
                        isRegister && password.length < 6 ->
                            Toast.makeText(context, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
                        isRegister -> {
                            savedName = name.trim()
                            savedEmail = email.trim()
                            savedPassword = password
                            isRegister = false
                            name = ""
                            email = savedEmail
                            password = ""
                            Toast.makeText(context, "Registration successful. Please log in.", Toast.LENGTH_LONG).show()
                        }
                        savedEmail.isNotEmpty() && email.trim() == savedEmail && password == savedPassword ->
                            loggedIn = true
                        else ->
                            Toast.makeText(context, "Invalid details. Register first.", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (isRegister) "REGISTER" else "LOGIN") }

            TextButton(
                onClick = {
                    isRegister = !isRegister
                    password = ""
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (isRegister) "Already have an account? Login" else "New user? Register here")
            }
        }
    }
}
