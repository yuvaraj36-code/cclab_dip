KOTLIN LOGIN + REGISTER DEMO (Jetpack Compose)

Setup:
1. ZIP extract pannunga.
2. Android Studio > Open > KotlinLoginRegister folder select pannunga.
3. Gradle Sync complete aagattum.
4. Emulator/device select panni Run (▶) click pannunga.

Use:
1. Register click panni name, email, password (minimum 6 characters) enter pannunga.
2. Registration success aana Login page-ku thirumbum.
3. Same email/password use panni login pannunga.
4. Logout button use pannalaam.

Note: Idhu demo mattum. Registration details app process memory-la mattum irukkum; app close aana details poidum. Real authentication-ku secure backend/auth service use pannunga.
